/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTimePicker;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Scoobydo
 */
public class ChiTietChuyenDiController implements Initializable {

    @FXML
    private JFXTextField tfMaChuyenDi;
    @FXML
    private JFXButton btnMoi;
    @FXML
    private JFXButton btnLuu;
    @FXML
    private JFXButton btnXoa;
    @FXML
    private JFXTimePicker tpThoiGian;
    @FXML
    private JFXTextArea taHoatDong;
    @FXML
    private JFXTextArea taGhiChu;
    @FXML
    private TableView<?> tbChiTietChuyenDi;
    @FXML
    private TableColumn<?, ?> colMaChuyenDi;
    @FXML
    private TableColumn<?, ?> colThoiGian;
    @FXML
    private TableColumn<?, ?> colHoatDong;
    @FXML
    private TableColumn<?, ?> colGhiChu;
    @FXML
    private JFXButton btnTroLai;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    public void setTextFieldMaChuyenDi(String maChuyenDi){
        tfMaChuyenDi.setText(maChuyenDi);
    }
    @FXML
    private void btnMoiClick(ActionEvent event) {
    }


    @FXML
    private void btnXoaClick(ActionEvent event) {
    }

    @FXML
    private void TableHocSInhClick(MouseEvent event) {
    }

    @FXML
    private void btnLuuClick(ActionEvent event) {
    }

    @FXML
    private void btnTroLaiClick(ActionEvent event) {
    }
    
}
